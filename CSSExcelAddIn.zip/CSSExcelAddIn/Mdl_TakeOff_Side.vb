﻿Imports System.Windows.Forms
Imports Microsoft.Office.Interop.Excel

Module Mdl_TakeOff_Side
    Function IsTakeOffTemplate(wBook As Workbook) As Boolean
        If wBook.CodeName.Contains("TakeOff_Template") Then
            IsTakeOffTemplate = True
        Else
            IsTakeOffTemplate = False
            ShowWarningMessage("Current workbook is not [Take-off Template]")
        End If
    End Function
    Function IsFabricUSCS(wSheet As Worksheet) As Boolean
        If wSheet.CodeName.Contains("Fabric_USCS") Then
            IsFabricUSCS = True
        Else
            IsFabricUSCS = False
            MsgBox(Prompt:="Sorry, this function only supported for [Fabric (USCS)] now")
        End If
    End Function

    Function FindRange(cell As Range, searchString As String) As Range
        FindRange = cell.CurrentRegion.EntireRow.Find(
            What:=searchString,
            After:=cell,
            LookIn:=XlFindLookIn.xlValues,
            LookAt:=XlLookAt.xlPart,
            SearchOrder:=XlSearchOrder.xlByRows,
            SearchDirection:=XlSearchDirection.xlNext,
            MatchCase:=False,
            SearchFormat:=True)
    End Function

    Sub ClearMark()
        Dim xlApp As Excel.Application : xlApp = GetObject(, "Excel.Application")
        Dim wBook As Excel.Workbook : wBook = xlApp.ActiveWorkbook
        Dim wSheet As Excel.Worksheet
        Dim cell As Range

        For Each wSheet In wBook.Sheets
            For Each cell In wSheet.UsedRange
                If Not cell.Comment Is Nothing Then
                    If cell.Comment.Text = notiText Then cell.Comment.Delete()
                ElseIf cell.Interior.Color = vbRose Then
                    cell.Interior.Color = vbBlack
                    cell.Font.Color = vbWhite
                End If
            Next
        Next
    End Sub

    Sub GetRangeDictionary(ByRef dict As Object)
        Dim key As Object
        For Each key In dict.Keys
            If Not TypeName(dict(key)) = "Range" Then dict.Remove(key)
        Next
    End Sub

    Function CheckRangeDictionary(ipDict As Object) As Boolean
        CheckRangeDictionary = True
        Call GetRangeDictionary(ipDict)
        Dim nRow As Integer
        Dim key As Object
        For Each key In ipDict.Keys
            ipDict(key).Interior.color = vbRose
            ipDict(key).Font.color = vbBlack
            If nRow = 0 Then
                nRow = ipDict(key).row
            Else
                If ipDict(key).row <> nRow Then
                    CheckRangeDictionary = False
                    ShowWarningMessage("WRONG TITTLE INPUT")
                    Exit Function
                End If
            End If
        Next
    End Function

    Sub OffsetRangeDictionary(ByRef dict As Object)
        Call GetRangeDictionary(dict)
        Dim key As Object
        For Each key In dict.Keys
            dict(key) = dict(key).offset(1, 0)
        Next
    End Sub

    Function IsEqual(num1 As Double, num2 As Double) As Boolean
        If Math.Round(num1 - num2, 0) = 0 Then IsEqual = True
    End Function

    Function GetTotal(ipDict As Object, key As String, item As Double)  'OK
        If Not item = 0 Then ipDict(key) = ipDict(key) + item
    End Function

    Function GetValue(cell As Object) As Double
        If Not IsError(cell) Then GetValue = Val(cell)
    End Function

    Function GetTotalDictionary(ByRef dictTotal As Object, ByVal dictInput As Object) 'OK
        Dim key1st As Object
        Dim key2nd As Object
        Dim key3rd As Object
        If Not dictTotal.Count > 0 Then
            dictTotal = dictInput
        Else
            For Each key1st In dictInput.Keys
                If Not TypeName(dictInput(key1st)) = "Dictionary" Then
                    Call GetTotal(dictTotal, CStr(key1st), dictInput(key1st))
                Else
                    For Each key2nd In dictInput(key1st).Keys
                        If Not TypeName(dictInput(key1st)(key2nd)) = "Dictionary" Then
                            Call GetTotal(dictTotal(key1st), CStr(key2nd), dictInput(key1st).item(key2nd))
                        Else
                            For Each key3rd In dictInput(key1st)(key2nd).Keys
                                Call GetTotal(dictTotal(key1st).item(key2nd), CStr(key3rd), dictInput(key1st)(key2nd).item(key3rd))
                            Next
                        End If
                    Next
                End If
            Next
        End If
    End Function

    Function GetSimpleDictionary(ByRef ipDict As Object)
        Dim resultDict As Object : resultDict = CreateObject("Scripting.Dictionary")
        Dim key1st As Object
        Dim key2nd As Object
        Dim key3rd As Object

        For Each key1st In ipDict.Keys
            If Not TypeName(ipDict(key1st)) = "Dictionary" Then
                resultDict(key1st) = ipDict(key1st)
            Else
                For Each key2nd In ipDict(key1st).Keys
                    If Not TypeName(ipDict(key1st)(key2nd)) = "Dictionary" Then
                        resultDict(key2nd) = ipDict(key1st)(key2nd)
                    Else
                        For Each key3rd In ipDict(key1st)(key2nd).Keys
                            resultDict(key3rd) = ipDict(key1st)(key2nd)(key3rd)
                        Next
                    End If
                Next
            End If
        Next
        ipDict = resultDict
    End Function

    Function CreateDifferentMark(tittle As String, vbColor As Long) 'OK
        Dim xlApp As Excel.Application : xlApp = GetObject(, "Excel.Application")
        Dim wBook As Excel.Workbook : wBook = xlApp.ActiveWorkbook
        Dim wSheet As Worksheet : wSheet = wBook.ActiveSheet
        Dim rng As Range : rng = wSheet.UsedRange
        Dim cell As Range

        For Each cell In rng
            If Not IsEmpty(cell) And Not IsHidden(cell) And Not IsError(cell) Then
                If cell.Value = tittle Then
                    cell.AddComment(Text:=notiText)
                    cell.Comment.Visible = True
                    With cell.Comment.Shape
                        .TextFrame.Characters.Font.Size = 8
                        .TextFrame.Characters.Font.FontStyle = "Bold"
                        .TextFrame.AutoSize = True
                        .Fill.ForeColor.RGB = vbColor
                        .Left = .Left + 150
                        .Top = .Top + 10
                    End With
                End If
            End If
        Next
    End Function
End Module
