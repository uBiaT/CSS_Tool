﻿Partial Class MyRibbon
    Inherits Microsoft.Office.Tools.Ribbon.RibbonBase

    <System.Diagnostics.DebuggerNonUserCode()>
    Public Sub New(ByVal container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        If (container IsNot Nothing) Then
            container.Add(Me)
        End If

    End Sub

    <System.Diagnostics.DebuggerNonUserCode()>
    Public Sub New()
        MyBase.New(Globals.Factory.GetRibbonFactory())

        'This call is required by the Component Designer.
        InitializeComponent()

    End Sub

    'Component overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Tab_CSSTool = Me.Factory.CreateRibbonTab
        Me.Grp_Infor = Me.Factory.CreateRibbonGroup
        Me.Btn_About = Me.Factory.CreateRibbonButton
        Me.Grp_Greneral = Me.Factory.CreateRibbonGroup
        Me.Btn_UnhideSheets = Me.Factory.CreateRibbonButton
        Me.Grp_TakeOff = Me.Factory.CreateRibbonGroup
        Me.Btn_Report = Me.Factory.CreateRibbonButton
        Me.Tab_CSSTool.SuspendLayout()
        Me.Grp_Infor.SuspendLayout()
        Me.Grp_Greneral.SuspendLayout()
        Me.Grp_TakeOff.SuspendLayout()
        Me.SuspendLayout()
        '
        'Tab_CSSTool
        '
        Me.Tab_CSSTool.ControlId.ControlIdType = Microsoft.Office.Tools.Ribbon.RibbonControlIdType.Office
        Me.Tab_CSSTool.Groups.Add(Me.Grp_Infor)
        Me.Tab_CSSTool.Groups.Add(Me.Grp_Greneral)
        Me.Tab_CSSTool.Groups.Add(Me.Grp_TakeOff)
        Me.Tab_CSSTool.Label = "CSS Tools"
        Me.Tab_CSSTool.Name = "Tab_CSSTool"
        '
        'Grp_Infor
        '
        Me.Grp_Infor.Items.Add(Me.Btn_About)
        Me.Grp_Infor.Label = "Information"
        Me.Grp_Infor.Name = "Grp_Infor"
        '
        'Btn_About
        '
        Me.Btn_About.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.Btn_About.Image = Global.CSSExcelAddIn.My.Resources.Resources.information
        Me.Btn_About.Label = "About"
        Me.Btn_About.Name = "Btn_About"
        Me.Btn_About.ShowImage = True
        '
        'Grp_Greneral
        '
        Me.Grp_Greneral.Items.Add(Me.Btn_UnhideSheets)
        Me.Grp_Greneral.Label = "Greneral"
        Me.Grp_Greneral.Name = "Grp_Greneral"
        '
        'Btn_UnhideSheets
        '
        Me.Btn_UnhideSheets.Image = Global.CSSExcelAddIn.My.Resources.Resources.unhide
        Me.Btn_UnhideSheets.Label = "Unhide Sheets"
        Me.Btn_UnhideSheets.Name = "Btn_UnhideSheets"
        Me.Btn_UnhideSheets.ShowImage = True
        '
        'Grp_TakeOff
        '
        Me.Grp_TakeOff.Items.Add(Me.Btn_Report)
        Me.Grp_TakeOff.Label = "Take-off"
        Me.Grp_TakeOff.Name = "Grp_TakeOff"
        '
        'Btn_Report
        '
        Me.Btn_Report.ControlSize = Microsoft.Office.Core.RibbonControlSize.RibbonControlSizeLarge
        Me.Btn_Report.Image = Global.CSSExcelAddIn.My.Resources.Resources.search
        Me.Btn_Report.Label = "Report"
        Me.Btn_Report.Name = "Btn_Report"
        Me.Btn_Report.ShowImage = True
        '
        'MyRibbon
        '
        Me.Name = "MyRibbon"
        Me.RibbonType = "Microsoft.Excel.Workbook"
        Me.Tabs.Add(Me.Tab_CSSTool)
        Me.Tab_CSSTool.ResumeLayout(False)
        Me.Tab_CSSTool.PerformLayout()
        Me.Grp_Infor.ResumeLayout(False)
        Me.Grp_Infor.PerformLayout()
        Me.Grp_Greneral.ResumeLayout(False)
        Me.Grp_Greneral.PerformLayout()
        Me.Grp_TakeOff.ResumeLayout(False)
        Me.Grp_TakeOff.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Tab_CSSTool As Microsoft.Office.Tools.Ribbon.RibbonTab
    Friend WithEvents Grp_Infor As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents Btn_About As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents Grp_TakeOff As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents Btn_Report As Microsoft.Office.Tools.Ribbon.RibbonButton
    Friend WithEvents Grp_Greneral As Microsoft.Office.Tools.Ribbon.RibbonGroup
    Friend WithEvents Btn_UnhideSheets As Microsoft.Office.Tools.Ribbon.RibbonButton
End Class

Partial Class ThisRibbonCollection

    <System.Diagnostics.DebuggerNonUserCode()> _
    Friend ReadOnly Property MyRibbon() As MyRibbon
        Get
            Return Me.GetRibbon(Of MyRibbon)()
        End Get
    End Property
End Class
