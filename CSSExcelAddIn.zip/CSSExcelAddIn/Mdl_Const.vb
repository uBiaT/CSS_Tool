﻿Imports System.Drawing

Module Mdl_Const
    'color
    Public vbBlack1 As Color = Color.FromArgb(1, 1, 1)
    Public vbWhite244 As Color = Color.FromArgb(244, 244, 244)
    Public vbOrange As Color = Color.FromArgb(255, 83, 8)
    Public vbRose As Color = Color.FromArgb(255, 153, 153)
    Public vbWhite As Color = Color.White
    Public vbBlack As Color = Color.Black
    Public vbGray As Color = Color.Gray
    Public vbGray50 As Color = Color.LightGray

    'string
    Public Const toolName As String = "CSS Tool v1.0"
    Public Const sumMark As String = "TAKE-OFF SUMMARY:"
    Public Const notiText As String = "CSS_CHECK THIS"

End Module
