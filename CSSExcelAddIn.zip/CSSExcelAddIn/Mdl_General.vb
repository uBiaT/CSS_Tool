﻿Imports Microsoft.Office.Interop.Excel

Module Mdl_General
    Sub ShowAboutBox()
        MsgBox(Prompt:=toolName & vbCr & "Developed by Tai Truong", Title:="About")
    End Sub
    Sub StartProcedure()
        Dim xlApp As Excel.Application = GetObject(, "Excel.Application")
        'xlApp.DisplayAlerts = False
        xlApp.ScreenUpdating = False
        'xlApp.EnableEvents = False
    End Sub
    Sub EndProcedure()
        Dim xlApp As Excel.Application = GetObject(, "Excel.Application")
        'xlApp.DisplayAlerts = True
        xlApp.ScreenUpdating = True
        'xlApp.EnableEvents = True
    End Sub

    Sub UnhideSheets()
        Dim xlApp As Excel.Application : xlApp = GetObject(, "Excel.Application")
        Dim wBook As Excel.Workbook : wBook = xlApp.ActiveWorkbook
        Dim wSheet As Excel.Worksheet

        Call StartProcedure()
        For Each wSheet In wBook.Sheets
            If Not wSheet.Visible = XlSheetVisibility.xlSheetVisible Then wSheet.Visible = XlSheetVisibility.xlSheetVisible
        Next
        Call EndProcedure()
    End Sub
End Module
