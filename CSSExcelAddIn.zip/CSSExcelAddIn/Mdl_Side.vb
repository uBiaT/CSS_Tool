﻿Imports Microsoft.Office.Interop.Excel

Module Mdl_Side
    Sub ShowWarningMessage(ByVal message As String)
        MsgBox(Prompt:=message,
               Buttons:=vbOKOnly + vbCritical,
               Title:="Oops!!!")
    End Sub

    Sub ShowInformationMessage(ByVal message As String)
        MsgBox(Prompt:=message,
               Buttons:=vbOKOnly + vbInformation,
               Title:=toolName)
    End Sub

    Function IsHidden(rng As Range) As Boolean
        IsHidden = rng.Hidden
    End Function

    Function IsEmpty(rng As Range) As Boolean
        IsEmpty = IsNothing(rng.Value)
    End Function

    Function IsBlank(dictInput As Object) As Boolean 'OK
        Dim key As Object
        IsBlank = True
        For Each key In dictInput.Keys
            If dictInput(key).Borders(xlEdgeBottom).LineStyle = xlContinuous Then 'v1.1 - TT - MO

                IsBlank = False
                Exit Function
            End If
        Next
    End Function
End Module
