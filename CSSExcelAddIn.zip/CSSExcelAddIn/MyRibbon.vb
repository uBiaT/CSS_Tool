﻿Imports Microsoft.Office.Tools.Ribbon

Public Class MyRibbon

    Private Sub MyRibbon_Load(ByVal sender As System.Object, ByVal e As RibbonUIEventArgs) Handles MyBase.Load
        Btn_About.ScreenTip = "User ID: " & Globals.ThisAddIn.Application.UserName & "[" & Environ("USERNAME") & "]"
    End Sub

    Private Sub Btn_About_Click(sender As Object, e As RibbonControlEventArgs) Handles Btn_About.Click
        Call ShowAboutBox()
    End Sub

    Private Sub Btn_UnhideSheets_Click(sender As Object, e As RibbonControlEventArgs) Handles Btn_UnhideSheets.Click
        Call UnhideSheets()
    End Sub

    Private Sub Btn_Report_Click(sender As Object, e As RibbonControlEventArgs) Handles Btn_Report.Click
        Call Report()
    End Sub
End Class
