﻿Imports System.Drawing
Imports Microsoft.Office.Interop.Excel

Module Mdl_TakeOff_Main
    Sub Report()
        Dim xlApp As Excel.Application : xlApp = GetObject(, "Excel.Application")
        Dim wBook As Excel.Workbook : wBook = xlApp.ActiveWorkbook
        Dim wSheet As Worksheet : wSheet = wBook.ActiveSheet
        Dim rng As Range : rng = wSheet.UsedRange
        'Dim cell As Range

        Dim dictTable As New Dictionary(Of String, Integer)
        Dim dictSummary As New Dictionary(Of String, Integer)

        If Not IsTakeOffTemplate(wBook) Then Exit Sub

        If Not IsFabricUSCS(wSheet) Then Exit Sub

        On Error Resume Next
        Dim sumRow As Integer : sumRow = rng.Find(What:=sumMark, LookAt:=XlLookAt.xlPart).Row
        On Error GoTo 0

        Call StartProcedure()
        'Call ClearForm
        Call ClearMark()

        For Each cell In rng
            If Not IsEmpty(cell) And Not IsHidden(cell) Then
                If cell.Font.Color = vbBlack1 Then
                    Call GetTotalDictionary(dictTable, CheckTable(cell))
                ElseIf cell.Font.Color = vbWhite And cell.Interior.Color = vbOrange And cell.Row > sumRow Then
                    'Call GetTotalDictionary(dictSummary, CheckSum(cell))
                End If
            End If
        Next

        'Call PrintResult("TOTAL", dictTable)
        'Call FormatForm
        'Call CompareDictionary(dictTable, dictSummary)
        Call EndProcedure()
    End Sub

    Function CheckTable(ipCell As Range) As Object
        On Error Resume Next
        Dim rangeDict As New Dictionary(Of String, Range)
        rangeDict("surface") = FindRange(ipCell, "Surface Prep Area")
        rangeDict("lap") = FindRange(ipCell, "Lap Area")
        rangeDict("round") = FindRange(ipCell, "Corners to round")
        rangeDict("fill") = FindRange(ipCell, "Corners, expoxy fill")
        rangeDict("anchorName_1") = FindRange(ipCell, "Anchor name_1")
        rangeDict("anchorName_2") = FindRange(ipCell, "Anchor name_2")
        rangeDict("anchorName_3") = FindRange(ipCell, "Anchor name_3")
        rangeDict("anchorName_4") = FindRange(ipCell, "Anchor name_4")
        rangeDict("anchorQuantity_1") = FindRange(ipCell, "Total anchor(s)_1")
        rangeDict("anchorQuantity_2") = FindRange(ipCell, "Total anchor(s)_2")
        rangeDict("anchorQuantity_3") = FindRange(ipCell, "Total anchor(s)_3")
        rangeDict("anchorQuantity_4") = FindRange(ipCell, "Total anchor(s)_4")
        rangeDict("product") = FindRange(ipCell, "Product")
        rangeDict("productWidth") = FindRange(ipCell, "Product width")
        rangeDict("install") = FindRange(ipCell, "Total length ")
        rangeDict("install") = FindRange(ipCell, "FRP install area")
        rangeDict("fps") = FindRange(ipCell, "FPS Area")
        On Error GoTo 0

        Dim resultDict As New Dictionary(Of String, Object)
        resultDict("Surface area (under FRP):") = 0
        resultDict("Corners to round:") = 0
        resultDict("Corners, epoxy fill:") = 0
        resultDict("FRP Anchors:") = CreateObject("Scripting.Dictionary")
        resultDict("FRP Anchors:")("1") = CreateObject("Scripting.Dictionary")
        resultDict("FRP Anchors:")("2") = CreateObject("Scripting.Dictionary")
        resultDict("FRP Anchors:")("3") = CreateObject("Scripting.Dictionary")
        resultDict("FRP Anchors:")("4") = CreateObject("Scripting.Dictionary")
        resultDict("FRP install:") = CreateObject("Scripting.Dictionary")
        resultDict("Coating:") = CreateObject("Scripting.Dictionary")

        If Not CheckRangeDictionary(rangeDict) Then Exit Function

        Do
            Call OffsetRangeDictionary(rangeDict)
            If IsBlank(rangeDict) Then Exit Do
            Call GetTotal(resultDict, "Surface area (under FRP):", GetValue(rangeDict("surface")) - GetValue(rangeDict("lap")))
            Call GetTotal(resultDict, "Corners to round:", GetValue(rangeDict("round")))
            Call GetTotal(resultDict, "Corners, epoxy fill:", GetValue(rangeDict("fill")))
            Call GetTotal(resultDict.item("FRP Anchors:").item("1"), rangeDict("anchorName_1"), GetValue(rangeDict("anchorQuantity_1")))
            Call GetTotal(resultDict.item("FRP Anchors:").item("2"), rangeDict("anchorName_2"), GetValue(rangeDict("anchorQuantity_2")))
            Call GetTotal(resultDict.item("FRP Anchors:").item("3"), rangeDict("anchorName_3"), GetValue(rangeDict("anchorQuantity_3")))
            Call GetTotal(resultDict.item("FRP Anchors:").item("4"), rangeDict("anchorName_4"), GetValue(rangeDict("anchorQuantity_4")))
            Call GetTotal(resultDict.item("FRP install:"), rangeDict("product") & rangeDict("productWidth"), GetValue(rangeDict("install")))
            Call GetTotal(resultDict("Coating:"), "CSS V-Wrap FPS", GetValue(rangeDict("fps")))
        Loop

        CheckTable = resultDict
        Call PrintResult(UCase(ipCell.Value), resultDict)
    End Function

    '    Function CheckSum(ipCell As Range) As Object 'OK
    '        Dim resultDict As Object :  Set resultDict = CreateObject("Scripting.Dictionary")
    '    Dim tittle As String
    '        Dim value As Double
    '        tittle = ipCell.Value
    '        If IsNumeric(ipCell.Offset(0, 1)) Then
    '            value = ipCell.Offset(0, 1).Value
    '        Else
    '            If IsNumeric(ipCell.Offset(0, 2)) Then
    '                value = ipCell.Offset(0, 2).Value
    '            End If
    '        End If
    '        Call GetTotal(resultDict, tittle, value)
    '    Set CheckSum = resultDict
    'End Function

    '    Function CompareDictionary(ipDict1 As Object, ipDict2 As Object) 'OK
    '        Dim resultDict As Object :  Set resultDict = CreateObject("Scripting.Dictionary")
    '    Dim key As Variant

    '        Call GetSimpleDictionary(ipDict1)
    '        For Each key In ipDict1
    '            If Not ipDict2.Exists(key) Then
    '                resultDict(key) = "NO DATA"
    '            Else
    '                If Not IsEqual(ipDict1(key), ipDict2(key)) Then
    '                    resultDict(key) = "MISMATCHED"
    '                Else
    '                    resultDict(key) = "MATCHED"
    '                End If
    '            End If
    '        Next

    '        Call GetSimpleDictionary(ipDict2)
    '        For Each key In ipDict2
    '            If Not ipDict1.Exists(key) Then
    '                resultDict(key) = "NO DATA"
    '            Else
    '                If Not IsEqual(ipDict1(key), ipDict2(key)) Then
    '                    resultDict(key) = "MISMATCHED"
    '                Else
    '                    resultDict(key) = "MATCHED"
    '                End If
    '            End If
    '        Next

    '        For Each key In resultDict
    '            Select Case resultDict(key)
    '                Case "NO DATA"
    '                    Call CreateDifferentMark(CStr(key), vbYellow)
    '                    Call HightLightDifferent(CStr(key), vbYellow)
    '                Case "MISMATCHED"
    '                    Call CreateDifferentMark(CStr(key), vbRed)
    '                    Call HightLightDifferent(CStr(key), vbRed)
    '                Case "MATCHED"
    '                    Call HightLightDifferent(CStr(key), vbGreen)
    '            End Select
    '        Next
    '    End Function
End Module
